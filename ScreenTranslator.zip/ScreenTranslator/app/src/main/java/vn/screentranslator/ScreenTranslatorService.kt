package vn.screentranslator

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Dịch vụ Trợ năng: theo dõi thay đổi trên màn hình → lấy chữ → dịch → hiện trên khung nổi.
 */
class ScreenTranslatorService : AccessibilityService(), OverlayController.Callbacks {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var overlay: OverlayController
    private lateinit var ocr: OcrReader
    private val translator = Translator()

    private var paused = false
    private var explaining = false
    private var explainJob: Job? = null
    private var refreshing = false
    private var lastSignature = ""
    private var debounceJob: Job? = null
    private var translateJob: Job? = null
    private var ocrLoopJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = OverlayController(this, this)
        ocr = OcrReader(this)
        overlay.show()
        updateTitle()
        overlay.setStatus("Sẵn sàng — mở app/trang cần dịch")
        startOcrLoop()
        schedule(0)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || paused || !::overlay.isInitialized || !overlay.expanded) return
        if (event.packageName?.toString() == packageName) return
        if (AppSettings.load(this).mode == Mode.OCR) return // chế độ OCR chạy theo nhịp riêng
        schedule(700)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        if (::overlay.isInitialized) overlay.remove()
        if (::ocr.isInitialized) ocr.close()
        translator.close()
        super.onDestroy()
    }

    // ---------------- Luồng chính ----------------

    private fun schedule(delayMs: Long) {
        debounceJob?.cancel()
        debounceJob = scope.launch { delay(delayMs); refresh(forceOcr = false) }
    }

    /** OCR định kỳ cho chế độ "Chỉ OCR" (video, game không phát sự kiện thay đổi). */
    private fun startOcrLoop() {
        ocrLoopJob?.cancel()
        ocrLoopJob = scope.launch {
            while (isActive) {
                val s = AppSettings.load(this@ScreenTranslatorService)
                if (s.mode == Mode.OCR && !paused && overlay.expanded) refresh(forceOcr = false)
                delay(s.ocrIntervalSec * 1000L)
            }
        }
    }

    private suspend fun refresh(forceOcr: Boolean) {
        if (refreshing || explaining) return
        refreshing = true
        try {
            val s = AppSettings.load(this)
            val root = rootInActiveWindow
            val pkg = root?.packageName?.toString()

            if (pkg == packageName) return
            if (pkg != null && pkg in s.excludedPackages && !forceOcr) {
                overlay.setStatus("Bỏ qua ứng dụng: $pkg")
                return
            }

            val screen = Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
            var segs: List<Seg> =
                if (!forceOcr && s.mode != Mode.OCR) {
                    TextCollector.collect(root, screen)
                        .filter { seg -> overlay.panelRect()?.let { !Rect.intersects(it, seg.bounds) } ?: true }
                } else emptyList()

            val needOcr = forceOcr || s.mode == Mode.OCR ||
                (s.mode == Mode.AUTO && segs.sumOf { it.text.length } < 15)
            if (needOcr) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    overlay.setStatus("Đang quét OCR…")
                    segs = ocr.read(overlay.panelRect())
                } else if (forceOcr || s.mode == Mode.OCR) {
                    overlay.setStatus("OCR cần Android 11 trở lên")
                    return
                }
            }

            val sig = segs.joinToString("\n") { it.text } + "|" + s.cacheKey + s.showOriginal
            if (sig == lastSignature && !forceOcr) return
            lastSignature = sig

            if (segs.isEmpty()) {
                overlay.showItems(emptyList(), s.showOriginal)
                overlay.setStatus("Không thấy chữ cần dịch")
                return
            }
            startTranslation(segs.map { it.text }, s)
        } finally {
            refreshing = false
        }
    }

    private fun startTranslation(texts: List<String>, s: AppSettings) {
        translateJob?.cancel()
        translateJob = scope.launch {
            overlay.showItems(texts.map { it to translator.cached(it, s) }, s.showOriginal)
            val engine = if (s.apiKey.isNotBlank()) "Claude" else "offline"
            overlay.setStatus("Đang dịch ${texts.size} đoạn ($engine)…")
            try {
                val map = translator.translate(texts, s)
                overlay.showItems(texts.map { it to map[it] }, s.showOriginal)
                overlay.setStatus("${texts.size} đoạn · $engine · chạm 1 dòng để xem giải thích")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastSignature = "" // cho phép thử lại ở lần thay đổi sau
                overlay.setStatus("Lỗi: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun updateTitle() {
        val s = AppSettings.load(this)
        overlay.setTitle("🇻🇳 ${s.domain.label} · ${s.mode.short}")
    }

    // ---------------- Nút trên khung nổi ----------------

    override fun onPauseToggled(paused: Boolean) {
        this.paused = paused
        if (!paused) { lastSignature = ""; schedule(0) } else translateJob?.cancel()
    }

    override fun onScanNow() {
        debounceJob?.cancel(); explainJob?.cancel()
        explaining = false
        scope.launch { refresh(forceOcr = true) }
    }

    override fun onModeCycle() {
        val cur = AppSettings.load(this).mode
        val next = Mode.values()[(cur.ordinal + 1) % Mode.values().size]
        AppSettings.setMode(this, next)
        updateTitle()
        lastSignature = ""
        schedule(0)
    }

    override fun onExplain(original: String) {
        explaining = true
        debounceJob?.cancel(); translateJob?.cancel(); explainJob?.cancel()
        overlay.showExplanation(original, null)
        overlay.setStatus("Đang giải thích…")
        explainJob = scope.launch {
            val s = AppSettings.load(this@ScreenTranslatorService)
            try {
                overlay.showExplanation(original, translator.explain(original, s))
                overlay.setStatus("Giải thích · ${s.domain.label}")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                overlay.showExplanation(original, "Lỗi: ${e.message ?: e.javaClass.simpleName}")
                overlay.setStatus("Lỗi")
            }
        }
    }

    override fun onBackToList() {
        explainJob?.cancel()
        explaining = false
        lastSignature = ""
        schedule(0)
    }

    override fun onExpandedChanged(expanded: Boolean) {
        if (expanded) { updateTitle(); lastSignature = ""; schedule(0) } else translateJob?.cancel()
    }
}
