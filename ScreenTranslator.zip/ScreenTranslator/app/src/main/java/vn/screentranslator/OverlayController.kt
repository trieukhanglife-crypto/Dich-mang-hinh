package vn.screentranslator

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

/**
 * Khung dịch nổi (TYPE_ACCESSIBILITY_OVERLAY: không cần quyền "hiển thị trên ứng dụng khác").
 * - Kéo thanh tiêu đề để di chuyển, kéo thanh ━━ ở đáy để đổi chiều cao.
 * - Nút "—" thu nhỏ thành bong bóng "VI"; chạm bong bóng để mở lại.
 */
class OverlayController(private val ctx: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun onPauseToggled(paused: Boolean)
        fun onScanNow()
        fun onModeCycle()
        fun onExpandedChanged(expanded: Boolean)
        fun onExplain(original: String)
        fun onBackToList()
    }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dm = ctx.resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    private val overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private val panelParams = WindowManager.LayoutParams(
        (dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.34).toInt(),
        overlayType, baseFlags, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = (dm.widthPixels * 0.03).toInt()
        y = (dm.heightPixels * 0.58).toInt()
    }

    private val bubbleParams = WindowManager.LayoutParams(
        dp(52), dp(52), overlayType, baseFlags, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dm.widthPixels - dp(64)
        y = dm.heightPixels / 3
    }

    private val titleView = TextView(ctx)
    private val statusView = TextView(ctx)
    private val listView = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val pauseBtn: TextView
    private val panel = LinearLayout(ctx)
    private val bubble = TextView(ctx)

    private var paused = false
    var expanded = false
        private set
    private var bubbleShown = false

    init {
        panel.orientation = LinearLayout.VERTICAL
        panel.background = GradientDrawable().apply {
            setColor(0xEB1E1F22.toInt()); cornerRadius = dp(14).toFloat()
        }
        panel.setPadding(dp(10), dp(6), dp(10), dp(2))

        // --- Thanh tiêu đề ---
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView.apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(button("Chế độ") { cb.onModeCycle() })
        header.addView(button("Quét") { cb.onScanNow() })
        pauseBtn = button("⏸") {
            paused = !paused
            refreshPauseLabel()
            cb.onPauseToggled(paused)
        }
        header.addView(pauseBtn)
        header.addView(button("—") { collapse() })
        makeDraggable(header, panel, panelParams, null)
        panel.addView(header)

        statusView.apply { setTextColor(0xFF9AA0A6.toInt()); textSize = 11f }
        panel.addView(statusView)

        // --- Danh sách bản dịch ---
        listView.orientation = LinearLayout.VERTICAL
        scroll.addView(listView)
        panel.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // --- Tay nắm đổi kích thước ---
        val resize = TextView(ctx).apply {
            text = "━━━"; gravity = Gravity.CENTER; setTextColor(0xFF5F6368.toInt())
            setPadding(0, dp(2), 0, dp(4))
        }
        makeResizable(resize)
        panel.addView(resize, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // --- Bong bóng thu nhỏ ---
        bubble.apply {
            text = "VI"; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE6D93025.toInt()) }
        }
        makeDraggable(bubble, bubble, bubbleParams) { expand() }
    }

    private fun button(label: String, onClick: () -> Unit) = TextView(ctx).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f
        setPadding(dp(9), dp(5), dp(9), dp(5))
        background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(8).toFloat() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(5) }
        setOnClickListener { onClick() }
    }

    private fun refreshPauseLabel() {
        pauseBtn.text = if (paused) "▶" else "⏸"
        if (paused) setStatus("Đã tạm dừng")
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, target: View, params: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        params.x = sx + dx; params.y = sy + dy
                        runCatching { wm.updateViewLayout(target, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); true }
                else -> false
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeResizable(handle: View) {
        var sh = 0; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sh = panelParams.height; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.height = (sh + (e.rawY - ty).toInt()).coerceIn(dp(110), (dm.heightPixels * 0.9).toInt())
                    runCatching { wm.updateViewLayout(panel, panelParams) }
                    true
                }
                else -> true
            }
        }
    }

    // ---------------- API công khai ----------------

    fun show() {
        if (expanded) return
        wm.addView(panel, panelParams); expanded = true
    }

    fun collapse() {
        if (expanded) { runCatching { wm.removeView(panel) }; expanded = false }
        if (!bubbleShown) { wm.addView(bubble, bubbleParams); bubbleShown = true }
        cb.onExpandedChanged(false)
    }

    fun expand() {
        if (bubbleShown) { runCatching { wm.removeView(bubble) }; bubbleShown = false }
        show()
        cb.onExpandedChanged(true)
    }

    fun remove() {
        if (expanded) runCatching { wm.removeView(panel) }
        if (bubbleShown) runCatching { wm.removeView(bubble) }
        expanded = false; bubbleShown = false
    }

    /** Vùng khung dịch trên màn hình — để OCR bỏ qua chữ của chính nó. */
    fun panelRect(): Rect? {
        val v: View = when {
            expanded -> panel
            bubbleShown -> bubble
            else -> return null
        }
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    fun setTitle(t: String) { titleView.text = t }
    fun setStatus(t: String) { statusView.text = t }

    fun showItems(items: List<Pair<String, String?>>, showOriginal: Boolean) {
        listView.removeAllViews()
        for ((orig, tr) in items) {
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            if (showOriginal) {
                box.addView(TextView(ctx).apply {
                    text = orig; textSize = 11.5f; setTextColor(0xFF9AA0A6.toInt())
                })
            }
            box.addView(TextView(ctx).apply {
                text = tr ?: "…"; textSize = 15f
                setTextColor(if (tr == null) 0xFF80868B.toInt() else Color.WHITE)
            })
            box.setOnClickListener { cb.onExplain(orig) }
            listView.addView(box)
        }
    }

    /** Màn giải thích chi tiết cho một dòng; body = null nghĩa là đang tải. */
    fun showExplanation(original: String, body: String?) {
        listView.removeAllViews()
        listView.addView(button("← Quay lại danh sách") { cb.onBackToList() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4); bottomMargin = dp(6) }
        })
        listView.addView(TextView(ctx).apply {
            text = original; textSize = 12f; setTextColor(0xFF9AA0A6.toInt())
            setPadding(0, 0, 0, dp(6))
        })
        listView.addView(TextView(ctx).apply {
            text = body ?: "Đang giải thích…"; textSize = 14.5f
            setTextColor(if (body == null) 0xFF80868B.toInt() else Color.WHITE)
            setLineSpacing(dp(2).toFloat(), 1f)
        })
        scroll.scrollTo(0, 0)
    }
}
