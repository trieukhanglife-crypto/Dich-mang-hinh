package vn.screentranslator

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class Seg(val text: String, val bounds: Rect)

/** Đọc chữ trực tiếp từ cây giao diện qua Accessibility — không cần chụp màn hình. */
object TextCollector {

    private val VI_CHARS = Regex("[ăâđêôơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]", RegexOption.IGNORE_CASE)

    fun collect(root: AccessibilityNodeInfo?, screen: Rect, maxChars: Int = 4000): List<Seg> {
        if (root == null) return emptyList()
        val out = mutableListOf<Seg>()
        val seen = HashSet<String>()

        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 80) return
            if (!n.isVisibleToUser) return
            if (!n.isPassword) {
                val t = (n.text ?: n.contentDescription)?.toString()?.replace(Regex("\\s+"), " ")?.trim()
                if (!t.isNullOrEmpty() && worthTranslating(t) && seen.add(t)) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    if (Rect.intersects(r, screen)) out += Seg(t, r)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)

        // Thứ tự đọc: trên → dưới, trái → phải
        out.sortWith(compareBy<Seg>({ it.bounds.top / 24 }, { it.bounds.left }))
        var total = 0
        return out.takeWhile { total += it.text.length; total <= maxChars }
    }

    fun worthTranslating(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters < 2) return false
        // Đã là tiếng Việt thì bỏ qua
        val vi = VI_CHARS.findAll(t).count()
        return vi.toFloat() / letters < 0.08f
    }
}

/** Quét OCR ảnh màn hình (API 30+) bằng ML Kit — dùng cho video, game, ảnh, PDF scan. */
class OcrReader(private val service: AccessibilityService) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun read(exclude: Rect?): List<Seg> = suspendCancellableCoroutine { cont ->
        service.takeScreenshot(
            Display.DEFAULT_DISPLAY,
            service.mainExecutor,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    result.hardwareBuffer.close()
                    if (bmp == null) {
                        if (cont.isActive) cont.resume(emptyList()); return
                    }
                    recognizer.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { txt ->
                            val segs = txt.textBlocks.mapNotNull { b ->
                                val box = b.boundingBox ?: return@mapNotNull null
                                // Bỏ chữ nằm trong chính khung dịch của mình
                                if (exclude != null && Rect.intersects(box, exclude)) return@mapNotNull null
                                val t = b.text.replace('\n', ' ').trim()
                                if (TextCollector.worthTranslating(t)) Seg(t, box) else null
                            }.sortedWith(compareBy<Seg>({ it.bounds.top / 24 }, { it.bounds.left }))
                            bmp.recycle()
                            if (cont.isActive) cont.resume(segs)
                        }
                        .addOnFailureListener {
                            bmp.recycle()
                            if (cont.isActive) cont.resume(emptyList())
                        }
                }

                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) cont.resume(emptyList())
                }
            }
        )
    }

    fun close() = recognizer.close()
}
