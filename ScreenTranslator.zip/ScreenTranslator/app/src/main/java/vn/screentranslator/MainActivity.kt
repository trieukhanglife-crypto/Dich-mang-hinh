package vn.screentranslator

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/** Màn hình cài đặt (giao diện dựng bằng code, không cần file layout). */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var domain: Spinner
    private lateinit var source: Spinner
    private lateinit var mode: Spinner
    private lateinit var interval: EditText
    private lateinit var showOriginal: CheckBox
    private lateinit var glossary: EditText
    private lateinit var excluded: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(28))
        }

        statusView = TextView(this).apply { textSize = 15f; typeface = Typeface.DEFAULT_BOLD }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "Bật / tắt dịch vụ trong Trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(note(
            "Nếu mục bị mờ (\"Cài đặt bị hạn chế\" trên Android 13+): bấm nút dưới → ⋮ góc phải → " +
                "\"Cho phép cài đặt bị hạn chế\", rồi quay lại bật."
        ))
        root.addView(Button(this).apply {
            text = "Mở thông tin ứng dụng"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        })

        root.addView(label("Claude API key (để trống = dịch offline, không theo chuyên ngành)"))
        apiKey = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "sk-ant-..."
        }
        root.addView(apiKey)

        root.addView(label("Model"))
        model = EditText(this).apply { setSingleLine(); hint = DEFAULT_MODEL }
        root.addView(model)

        root.addView(label("Chuyên ngành"))
        domain = spinner(Domain.values().map { it.label })
        root.addView(domain)

        root.addView(label("Ngôn ngữ nguồn"))
        source = spinner(SOURCE_LANGS.map { it.second })
        root.addView(source)

        root.addView(label("Chế độ đọc màn hình"))
        mode = spinner(Mode.values().map { it.label })
        root.addView(mode)

        root.addView(label("Chu kỳ quét OCR (giây)"))
        interval = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(interval)

        showOriginal = CheckBox(this).apply { text = "Hiện cả câu gốc phía trên bản dịch" }
        root.addView(showOriginal)

        root.addView(label("Bảng thuật ngữ riêng (mỗi dòng: thuật ngữ = bản dịch)"))
        glossary = EditText(this).apply {
            minLines = 5; gravity = Gravity.TOP
            hint = "AOG = tàu bay nằm đất chờ vật tư\nsafety wire = dây hãm an toàn\ntorque = lực siết"
        }
        root.addView(glossary)

        root.addView(label("Bỏ qua ứng dụng (package, mỗi dòng 1) — vd. app ngân hàng"))
        excluded = EditText(this).apply { minLines = 3; gravity = Gravity.TOP }
        root.addView(excluded)

        root.addView(Button(this).apply {
            text = "Lưu cài đặt"
            setOnClickListener { save() }
        })

        root.addView(note(
            "Quyền riêng tư: chữ trên màn hình được gửi tới Anthropic API để dịch khi có API key. " +
                "Ô mật khẩu luôn bị bỏ qua. Dùng nút ⏸ trên khung nổi hoặc danh sách \"Bỏ qua ứng dụng\" cho nội dung nhạy cảm."
        ))

        setContentView(ScrollView(this).apply { addView(root) })
        load()
    }

    override fun onResume() {
        super.onResume()
        val on = isServiceEnabled()
        statusView.text = if (on) "✅ Dịch vụ đang bật — khung dịch nổi đang hoạt động" else "⚠️ Dịch vụ chưa bật"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun load() {
        val s = AppSettings.load(this)
        apiKey.setText(s.apiKey)
        model.setText(s.model)
        domain.setSelection(s.domain.ordinal)
        source.setSelection(SOURCE_LANGS.indexOfFirst { it.first == s.sourceLang }.coerceAtLeast(0))
        mode.setSelection(s.mode.ordinal)
        interval.setText(s.ocrIntervalSec.toString())
        showOriginal.isChecked = s.showOriginal
        glossary.setText(s.glossary)
        excluded.setText(s.excludedPackages.joinToString("\n"))
    }

    private fun save() {
        val s = AppSettings(
            apiKey = apiKey.text.toString().trim(),
            model = model.text.toString().trim().ifBlank { DEFAULT_MODEL },
            domain = Domain.values()[domain.selectedItemPosition],
            sourceLang = SOURCE_LANGS[source.selectedItemPosition].first,
            mode = Mode.values()[mode.selectedItemPosition],
            ocrIntervalSec = interval.text.toString().toIntOrNull()?.coerceIn(1, 30) ?: 2,
            showOriginal = showOriginal.isChecked,
            glossary = glossary.text.toString(),
            excludedPackages = excluded.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
        )
        AppSettings.save(this, s)
        Toast.makeText(this, "Đã lưu. Khung dịch áp dụng ngay ở lần cập nhật tới.", Toast.LENGTH_SHORT).show()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(14), 0, dp(2))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setPadding(0, dp(6), 0, dp(4)); alpha = 0.75f
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }
}
