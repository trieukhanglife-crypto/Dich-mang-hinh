package vn.screentranslator

import android.content.Context

const val DEFAULT_MODEL = "claude-haiku-5-5"

enum class Mode(val label: String, val short: String) {
    AUTO("Tự động (đọc chữ, OCR khi cần)", "Tự động"),
    TEXT("Chỉ đọc chữ (Trợ năng)", "Chữ"),
    OCR("Chỉ quét OCR (video, game, ảnh)", "OCR"),
}

/** Chuyên ngành: nhãn hiển thị + hướng dẫn thuật ngữ đưa vào prompt. */
enum class Domain(val label: String, val guide: String) {
    GENERAL(
        "Tổng quát",
        "Văn bản thông dụng; dịch tự nhiên, dễ hiểu."
    ),
    AVIATION(
        "Hàng không / Bảo dưỡng tàu bay",
        "Kỹ thuật và bảo dưỡng tàu bay (AMM, IPC, TSM, MEL/CDL, SRM, WDM, SB, AD, Task Card, quy trình EASA Part-145/Part-66, FAA, ICAO, Cục Hàng không Việt Nam). " +
            "Dùng thuật ngữ mà kỹ sư, thợ máy tàu bay Việt Nam thực sự dùng. Với MỖI từ viết tắt: giữ nguyên chữ viết tắt và thêm nghĩa tiếng Việt ngắn trong ngoặc, " +
            "ví dụ: APU (bộ động lực phụ), CRS (chứng chỉ cho phép khai thác trở lại), NDT (kiểm tra không phá hủy). " +
            "WARNING = CẢNH BÁO, CAUTION = CHÚ Ý, NOTE = GHI CHÚ. Giữ nguyên tuyệt đối: số chương ATA, part number, mã task, giá trị lực siết, áp suất, nhiệt độ, dung sai, đơn vị. " +
            "Tên hệ thống và tên bộ phận phổ biến bằng tiếng Anh trong xưởng (bleed air, pylon, slat, flap, actuator…) có thể giữ tiếng Anh kèm nghĩa."
    ),
    IT(
        "Kỹ thuật / IT",
        "Công nghệ thông tin, phần mềm, mạng, bảo mật, phần cứng. Với thuật ngữ mà dân IT Việt Nam vẫn quen dùng tiếng Anh " +
            "(API, server, framework, commit, deploy, cache, bug, log…) thì giữ nguyên tiếng Anh, có thể kèm nghĩa Việt trong ngoặc lần đầu. " +
            "Thuật ngữ đã có tên Việt phổ biến thì dùng tên Việt (cơ sở dữ liệu, mã nguồn, mạng nội bộ, tường lửa…)."
    ),
    MEDICAL(
        "Y khoa / Dược",
        "Y khoa, dược học, xét nghiệm, chẩn đoán. Dùng thuật ngữ y khoa chuẩn tại Việt Nam (như trong văn bản Bộ Y tế, sách giáo khoa Y). " +
            "Tên thuốc giữ tên hoạt chất quốc tế (INN); liều lượng, đơn vị, chỉ số xét nghiệm giữ nguyên. Tuyệt đối không thay đổi con số."
    ),
    LEGAL(
        "Pháp lý / Hợp đồng",
        "Pháp lý, hợp đồng, điều khoản. Dùng văn phong và thuật ngữ pháp lý Việt Nam (Bên A/Bên B, điều khoản, nghĩa vụ, " +
            "bồi thường thiệt hại, bất khả kháng, chấm dứt hợp đồng, luật điều chỉnh, tranh chấp, trọng tài…). Dịch chính xác, không diễn giải."
    ),
    FINANCE(
        "Kinh tế / Tài chính",
        "Kinh tế, tài chính, kế toán, ngân hàng, chứng khoán. Dùng thuật ngữ theo chuẩn mực kế toán Việt Nam (VAS) và thị trường chứng khoán VN " +
            "(doanh thu thuần, lợi nhuận gộp, bảng cân đối kế toán, dòng tiền, cổ tức, vốn hóa…). Mã cổ phiếu, số liệu giữ nguyên."
    ),
    ENGINEERING(
        "Cơ khí / Điện / Xây dựng",
        "Kỹ thuật cơ khí, điện, điện tử, xây dựng, tự động hóa. Dùng thuật ngữ theo TCVN và cách gọi của kỹ sư Việt Nam " +
            "(dung sai, mô-men xoắn, biến tần, tủ điện, cốt thép, bản vẽ thi công…). Ký hiệu, đơn vị, mã vật tư giữ nguyên."
    ),
    SCIENCE(
        "Khoa học / Học thuật",
        "Bài báo khoa học, giáo trình đại học. Dùng thuật ngữ học thuật chuẩn tiếng Việt; công thức, ký hiệu, tên loài, tên riêng giữ nguyên."
    ),
}

val SOURCE_LANGS = listOf(
    "auto" to "Tự nhận diện",
    "en" to "English",
    "zh" to "中文",
    "ja" to "日本語",
    "ko" to "한국어",
    "fr" to "Français",
    "de" to "Deutsch",
    "ru" to "Русский",
)

data class AppSettings(
    val apiKey: String,
    val model: String,
    val domain: Domain,
    val sourceLang: String,
    val mode: Mode,
    val ocrIntervalSec: Int,
    val showOriginal: Boolean,
    val glossary: String,
    val excludedPackages: Set<String>,
) {
    /** Đổi chuyên ngành / thuật ngữ / model → xoá bộ nhớ đệm bản dịch. */
    val cacheKey: String
        get() = "$model|$domain|$sourceLang|${glossary.hashCode()}|${apiKey.isNotBlank()}"

    fun glossaryPairs(): List<Pair<String, String>> = glossary.lines()
        .mapNotNull { line ->
            val i = line.indexOf('=')
            if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
        }
        .filter { it.first.isNotEmpty() && it.second.isNotEmpty() }

    companion object {
        private const val PREFS = "settings"

        fun load(c: Context): AppSettings {
            val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return AppSettings(
                apiKey = p.getString("apiKey", "")!!.trim(),
                model = p.getString("model", DEFAULT_MODEL)!!.ifBlank { DEFAULT_MODEL },
                domain = runCatching { Domain.valueOf(p.getString("domain", "AVIATION")!!) }.getOrDefault(Domain.AVIATION),
                sourceLang = p.getString("sourceLang", "auto")!!,
                mode = runCatching { Mode.valueOf(p.getString("mode", "AUTO")!!) }.getOrDefault(Mode.AUTO),
                ocrIntervalSec = p.getInt("ocrIntervalSec", 2).coerceIn(1, 30),
                showOriginal = p.getBoolean("showOriginal", true),
                glossary = p.getString("glossary", "")!!,
                excludedPackages = p.getString("excluded", DEFAULT_EXCLUDED)!!
                    .lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
            )
        }

        fun save(c: Context, s: AppSettings) {
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("apiKey", s.apiKey)
                .putString("model", s.model)
                .putString("domain", s.domain.name)
                .putString("sourceLang", s.sourceLang)
                .putString("mode", s.mode.name)
                .putInt("ocrIntervalSec", s.ocrIntervalSec)
                .putBoolean("showOriginal", s.showOriginal)
                .putString("glossary", s.glossary)
                .putString("excluded", s.excludedPackages.joinToString("\n"))
                .apply()
        }

        fun setMode(c: Context, m: Mode) {
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("mode", m.name).apply()
        }

        /** Mặc định bỏ qua bàn phím và vài app nhạy cảm; người dùng sửa được. */
        const val DEFAULT_EXCLUDED = "com.google.android.inputmethod.latin\ncom.samsung.android.honeyboard\ncom.android.systemui"
    }
}
