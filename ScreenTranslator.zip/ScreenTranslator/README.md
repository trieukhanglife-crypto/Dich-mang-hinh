# Dịch Màn Hình — lớp phủ dịch trực tiếp sang tiếng Việt (Android)

App đọc chữ đang hiển thị trên màn hình **trực tiếp, không cần chụp**, dịch sang tiếng Việt theo **thuật ngữ chuyên ngành**, và hiện bản dịch trong một **khung nổi** luôn nằm trên mọi ứng dụng.

## Cách hoạt động
| Chế độ | Đọc chữ bằng | Dùng cho |
|---|---|---|
| **Tự động** (mặc định) | Trợ năng (Accessibility); nếu màn hình gần như không có chữ thì tự quét OCR | Hầu hết app, web, email, tài liệu |
| **Chỉ đọc chữ** | Trợ năng | Nhanh, chính xác, tốn ít pin |
| **Chỉ OCR** | Tự quét ảnh màn hình mỗi N giây (ML Kit, chạy trên máy) | Video, game, ảnh, PDF dạng scan |

Phần dịch:
- **Có Claude API key** → dịch bằng AI, theo chuyên ngành (IT, Y khoa, Pháp lý, Tài chính, Cơ khí/Điện/Xây dựng, Khoa học) và **bảng thuật ngữ riêng** của bạn.
- **Không có key** → dịch offline bằng Google ML Kit (miễn phí, lần đầu tải gói khoảng 30MB, chất lượng phổ thông).

Khung nổi: kéo thanh tiêu đề để di chuyển, kéo thanh **━━━** để đổi chiều cao. Các nút: **Chế độ** (đổi Tự động/Chữ/OCR), **Quét** (bắt OCR ngay), **⏸** (tạm dừng), **—** (thu thành bong bóng "VI"; chạm để mở lại). Khi thu nhỏ hoặc tạm dừng thì app ngừng dịch, nên không tốn lượt gọi API.

**Chạm vào một dòng bất kỳ** trên khung dịch để xem màn giải thích: bản dịch đầy đủ, từng từ viết tắt (viết đầy đủ, nghĩa, vai trò) và vài câu giải thích như người hướng dẫn trong nghề. Bấm "← Quay lại danh sách" để tiếp tục dịch trực tiếp. Chuyên ngành mặc định là **Hàng không / Bảo dưỡng tàu bay**.

## Tạo file APK
### Cách 1 — Chỉ cần điện thoại (GitHub, miễn phí)
1. Vào github.com, tạo tài khoản và đăng nhập (nên bật "Desktop site" trong trình duyệt cho dễ bấm).
2. Bấm **+** → **New repository**, đặt tên `dich-man-hinh`, chọn **Private**, rồi bấm **Create repository**.
3. Bấm **uploading an existing file**, chọn file **ScreenTranslator.zip** (giữ nguyên, không giải nén), rồi bấm **Commit changes**.
4. Bấm **Add file → Create new file**. Ở ô tên file, gõ chính xác `.github/workflows/build.yml`. Mở file **build.yml** ra, copy toàn bộ nội dung và dán vào, rồi bấm **Commit changes**.
5. Chờ khoảng 5–10 phút (theo dõi ở tab **Actions**; chấm xanh là xong).
6. Về trang chính của repo → mục **Releases** ở bên phải (hoặc cuối trang) → bấm **DichManHinh.apk** để tải về và cài.

Muốn sửa app sau này: tải file zip mới lên đè file cũ là GitHub tự build lại, rồi bạn tải bản mới ở mục Releases.

### Cách 2 — Máy tính
Mở thư mục bằng **Android Studio** → *Build → Build APK(s)*, hoặc chạy `gradle assembleDebug`.

## Cài đặt và bật
1. Cài file APK (cho phép "Cài ứng dụng không rõ nguồn gốc" nếu máy hỏi).
2. Mở app **Dịch Màn Hình**, nhập API key (lấy tại console.anthropic.com), chọn chuyên ngành → **Lưu**.
3. Bấm **Bật dịch vụ trong Trợ năng** → *Ứng dụng đã cài đặt* → **Dịch Màn Hình** → bật.
   - Android 13 trở lên: nếu mục này bị mờ ("Cài đặt bị hạn chế"), vào *Thông tin ứng dụng* → ⋮ → **Cho phép cài đặt bị hạn chế**, rồi bật lại.
4. Khung dịch hiện lên. Mở app hoặc trang bất kỳ để bắt đầu dịch.

## Bảng thuật ngữ
Mỗi dòng một cặp theo dạng `thuật ngữ gốc = bản dịch`, ví dụ:
```
load balancer = bộ cân bằng tải
myocardial infarction = nhồi máu cơ tim
force majeure = bất khả kháng
```

## Lưu ý
- **Bản dịch chỉ để tham khảo, giúp bạn hiểu nhanh.** Khi thực hiện công việc bảo dưỡng, phải làm theo tài liệu gốc đã được phê chuẩn (AMM, TSM…). Mọi số liệu như lực siết, dung sai, giới hạn đều phải đọc từ bản gốc.
- Tài liệu bảo dưỡng của hãng có thể có quy định bảo mật. Hãy kiểm tra quy định của công ty trước khi gửi nội dung tài liệu ra ngoài để dịch bằng AI.
- **Quyền riêng tư:** khi có API key, chữ trên màn hình được gửi tới Anthropic API để dịch. Ô mật khẩu luôn bị bỏ qua. Hãy thêm app ngân hàng vào danh sách **Bỏ qua ứng dụng**, hoặc bấm ⏸ trước khi mở nội dung nhạy cảm.
- OCR cần **Android 11 trở lên** và hiện chỉ nhận dạng **chữ Latin** (Anh, Pháp, Đức…). Muốn OCR chữ Trung, Nhật, Hàn thì thêm thư viện `com.google.mlkit:text-recognition-chinese` (hoặc `-japanese`, `-korean`) và đổi `TextRecognizerOptions` trong `ScreenReaders.kt`. Chế độ **đọc chữ** thì đọc được mọi ngôn ngữ.
- Model mặc định là `claude-haiku-5-5` (nhanh, rẻ). Có thể đổi sang model mạnh hơn trong phần cài đặt nếu cần dịch chính xác hơn.
- Bản dịch được lưu đệm, nên chữ đã dịch rồi sẽ không gọi API lại.

## Cấu trúc mã
- `ScreenTranslatorService.kt` — dịch vụ Trợ năng, luồng chính đọc → dịch → hiển thị
- `ScreenReaders.kt` — đọc chữ qua cây giao diện, và OCR qua `takeScreenshot` + ML Kit
- `Translator.kt` — gọi Claude API (prompt chuyên ngành), dịch offline bằng ML Kit, bộ nhớ đệm
- `OverlayController.kt` — khung nổi và bong bóng
- `AppSettings.kt` — cài đặt, danh sách chuyên ngành và hướng dẫn thuật ngữ
- `MainActivity.kt` — màn hình cài đặt
